#if PRIME_TWEEN_SAFETY_CHECKS && UNITY_ASSERTIONS
#define SAFETY_CHECKS
#endif
using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using JetBrains.Annotations;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Jobs;
using UnityEngine;
using TweenType = PrimeTween.TweenAnimation.TweenType;

namespace PrimeTween {
    internal partial class ColdData {
        internal TweenArray _tweenArray;
        internal int _index;

        internal ColdData sequence;
        internal ColdData prev;
        internal ColdData next;
        internal ColdData prevSibling;
        internal ColdData nextSibling;

        [CanBeNull] internal Action<TweenData> onComplete;
        [CanBeNull] internal object onCompleteCallback;
        [CanBeNull] internal object onCompleteTarget;

        internal OnValueChangeDelegate onValueChange;
        internal object customOnValueChange; // or TweenAnimation.context

        internal AnimationCurve customEase;

        internal Blob blob;

        [CanBeNull] internal object onUpdateTarget; // or OnFinally target / Tween.Clock reference
        internal object onUpdateCallback; // or OnFinally callback
        internal Action<TweenData> onUpdate; // or OnFinally callback invoker

        internal long id = -1;
        internal CancellationToken cancellationToken;

        [CanBeNull] internal object waitPredicateTarget;
        [CanBeNull] internal object waitPredicate;
        [CanBeNull] internal Predicate<ColdData> waitPredicateShouldWait;

        #if UNITY_EDITOR
        internal string debugDescription;
        internal int indexInTweenAnimation;
        #endif



        internal bool hasData {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => _tweenArray != null && _index >= 0 && _tweenArray.GetData().Length > _index;
        }

        internal unsafe ref UnmanagedTweenData data {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get {
                Assert.IsTrue(hasData, null, nameof(hasData));
                return ref *(_tweenArray._dataPtr + _index);
            }
        }

        internal ref TweenData managedData {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get {
                Assert.IsTrue(hasData);
                return ref _tweenArray[_index];
            }
        }

        internal const int payloadSize = 28;
        internal const int userPayloadSize = 16;
        // The parametric ease lives at the end of the blob, so payloads of tweens that support parametric ease must end before this offset.
        // Shakes and text effects don't support parametric ease, so their payloads overwrite it. This is safe because a curve-less Ease.Custom is the only way to read it.
        internal const int parametricEaseOffset = payloadSize - 6;

        // Holds one payload at a time, depending on the tween type: the user's custom payload, ShakeData, MaterialPayload, additive tween's previous value, etc.
        // Accessed only with MemCpy because:
        // 1. A typed float load/store may widen the value (Mono without float32 mode, x87), which quiets signaling NaNs, corrupting arbitrary payload bits.
        // 2. MemCpy makes no alignment assumptions. A typed access may fault on 32-bit ARM if the blob is not aligned to the payload's alignment.
        internal unsafe struct Blob {
            fixed byte bytes[payloadSize];

            internal void Store<T>(T payload, int offset = 0) where T : unmanaged {
                #if SAFETY_CHECKS
                if (offset < 0 || offset + UnsafeUtility.SizeOf<T>() > payloadSize) {
                    throw new ArgumentOutOfRangeException(nameof(offset), $"'{typeof(T)}' of {UnsafeUtility.SizeOf<T>()} bytes at offset {offset} doesn't fit into the {payloadSize}-byte blob.");
                }
                #endif
                fixed (byte* p = bytes) {
                    UnsafeUtility.MemCpy(p + offset, &payload, UnsafeUtility.SizeOf<T>());
                }
            }

            internal T Load<T>(int offset = 0) where T : unmanaged {
                #if SAFETY_CHECKS
                if (offset < 0 || offset + UnsafeUtility.SizeOf<T>() > payloadSize) {
                    throw new ArgumentOutOfRangeException(nameof(offset), $"'{typeof(T)}' of {UnsafeUtility.SizeOf<T>()} bytes at offset {offset} doesn't fit into the {payloadSize}-byte blob.");
                }
                #endif
                T payload = default;
                fixed (byte* p = bytes) {
                    UnsafeUtility.MemCpy(&payload, p + offset, UnsafeUtility.SizeOf<T>());
                }
                return payload;
            }
        }

        internal ParametricEasePayload parametricEase {
            get => blob.Load<ParametricEasePayload>(parametricEaseOffset);
            set => blob.Store(value, parametricEaseOffset);
        }

        /// _getter is null for custom tweens
        internal void Setup([CanBeNull] object _target, ref TweenSettings _settings, bool _startFromCurrent, TweenType _tweenType, ref TweenData rt, ref UnmanagedTweenData d) {
            Assert.IsTrue(hasData);
            Assert.AreNotEqual(0, d.id);
            Assert.AreEqual(d.id, id);
            _settings.SetValidValues();
            Assert.IsTrue(_settings.cycles >= -1);
            Assert.AreNotEqual(TweenType.Disabled, _tweenType);

            var manager = PrimeTweenManager.Instance;
            var propType = Utils.TweenTypeToTweenData(_tweenType).Item1;
            Assert.AreNotEqual(PropType.None, propType);
            d.tweenType = _tweenType;
            if (_settings.ease == Ease.Default) {
                _settings.ease = manager.defaultEase;
            } else if (_settings.ease == Ease.Custom && _settings.parametricEase == ParametricEase.None) {
                AnimationCurve curve = _settings.customEase;
                if (curve != null && TweenSettings.ValidateCustomCurveKeyframes(curve)) {
                    var startKey = curve[0];
                    var endKey = curve[curve.length - 1];
                    d.IsCustomEaseSameStartEndValues = Mathf.Approximately(startKey.value, endKey.value);
                } else {
                    Debug.LogError($"Ease type is Ease.Custom, but {nameof(TweenSettings.customEase)} is not configured correctly.", _target as UnityEngine.Object);
                    _settings.ease = manager.defaultEase;
                }
            }

            Revive(ref d);

            d.flags |= Flags.WarnIgnoredOnCompleteIfTargetDestroyed;
            d.SetState(State.Before);
            d.easedInterpolationFactor = float.MinValue;
            d.cyclesDone = TweenData.iniCyclesDone;
            d.timeScale = 1f;

            d.animationDuration = _settings.duration;
            d.ease = _settings.ease;
            d.cyclesTotal = _settings.cycles;
            d.cycleMode = _settings.cycleMode;
            d.startDelay = _settings.startDelay;
            d.useUnscaledTime = _settings.useUnscaledTime;
            d.startFromCurrent = _startFromCurrent;

            if (_settings.parametricEase != ParametricEase.None) {
                // Evaluate() checks the curve first, so drop a leftover curve to keep the parametric ease's priority
                customEase = null;
                // the blob is zeroed on release, so a non-parametric ease doesn't need to be written
                parametricEase = new ParametricEasePayload { ease = _settings.parametricEase, strength = _settings.parametricEaseStrength, period = _settings.parametricEasePeriod };
            } else {
                customEase = _settings.customEase;
            }
            TweenData.CalculateCycleDuration(_settings.endDelay, ref d);
            Assert.IsTrue(d.cycleDuration >= 0);

            d.warnEndValueEqualsCurrent = manager.warnEndValueEqualsCurrent;

            if (!_startFromCurrent) {
                TweenData.CacheDiff(ref d, ref rt);
            }
            rt.target = _target;
        }

        void Revive(ref UnmanagedTweenData d) {
            // managedData.print("revive");
            Assert.IsFalse(d.isAlive);
            d.isAlive = true;
            #if UNITY_EDITOR
            debugDescription = null;
            indexInTweenAnimation = -1;
            #endif
        }

        internal ColdData FindMainSequence() {
            Assert.IsNotNull(sequence);
            var mainSequence = sequence;
            while (true) {
                var previous = mainSequence.prev;
                if (previous == null) {
                    break;
                }
                var parent = previous.sequence;
                if (parent == null) {
                    break;
                }
                mainSequence = parent;
            }
            return mainSequence;
        }

        // Tween.Custom never waits, so it reuses the Sequence wait fields
        internal ref object customGetter => ref waitPredicate;
        internal ref object customGetterInvoker => ref waitPredicateTarget;
        // Shakes and text effects never wait
        internal ref object shakeStrengthOverTime => ref waitPredicateTarget;
        internal ref object textEffectGradient => ref waitPredicateTarget;
    }

    internal struct MaterialPayload {
        internal int propId;
        internal int stPropId; // only MaterialPropertyBlockTextureScale/Offset: the id of the '{textureName}_ST' property
        internal int materialIndex;
    }

    // TweenTimeScale and TweenAwaiter store the id of the target tween to detect when the target is recycled
    internal struct TargetTweenIdPayload {
        internal long id;
    }

    internal struct SequencePayload {
        internal bool isEmpty;
        internal float waitTimeout; // only the main sequence root: the remaining timeout of the current WaitWhile/WaitUntil
    }

    internal struct WaitPayload {
        internal float timeout;
    }

    internal struct ParametricEasePayload {
        ushort strengthHalf, periodHalf;
        internal ParametricEase ease;

        // clamped because a half overflows to infinity, which turns the eased value into NaN
        internal float strength {
            get => UnityEngine.Mathf.HalfToFloat(strengthHalf);
            set => strengthHalf = UnityEngine.Mathf.FloatToHalf(Mathf.Clamp(value, -65504f, 65504f));
        }
        internal float period {
            get => UnityEngine.Mathf.HalfToFloat(periodHalf);
            set => periodHalf = UnityEngine.Mathf.FloatToHalf(Mathf.Clamp(value, -65504f, 65504f));
        }
    }

    [StructLayout(LayoutKind.Explicit, Size = 32)]
    internal struct TweenData : IEquatable<TweenData> {
        [FieldOffset(0)] internal TweenAnimation.ValueWrapper endValueOrDiff;
        /// Holds a reference to tween's target. If the target is UnityEngine.Object, the tween will gracefully stop when the target is destroyed. That is, destroying an object with running tweens is perfectly ok.
        /// Keep in mind: when animating plain C# objects (not derived from UnityEngine.Object), the plugin will hold a strong reference to the object for the entire tween duration.
        ///     If the plain C# target holds a reference to UnityEngine.Object and animates its properties, then it's the user's responsibility to ensure that UnityEngine.Object still exists.
        [FieldOffset(16)] [CanBeNull] internal object target;
        /// Item can be null if the list is accessed from the <see cref="UpdateAndCheckIfRunning"/> via onValueChange() or onComplete()
        [FieldOffset(24)] /*[CanBeNull]*/ internal ColdData cold;



        internal const float negativeElapsedTime = -1000f;

        internal ref ColdData sequence => ref cold.sequence;

        #if UNITY_EDITOR
        internal ref string debugDescription => ref cold.debugDescription;
        #endif
        internal ref long id => ref cold.id;

        internal const int iniCyclesDone = -1;

        internal bool UpdateAndCheckIfRunning(float dt, ref UnmanagedTweenData d) {
            Assert.IsFalse(d.isUpdating);
            if (!d.isAlive) {
                return d.isInSequence; // don't release a tween until sequence.ReleaseTweens()
            }
            // check before the 'isPaused' early-out: cancellation should stop paused animations too
            if (d.HasCancellationToken && cold.cancellationToken.IsCancellationRequested) {
                Tween.CancelTweenOrSequence(new Tween(cold));
                return d.isAlive; // returning 'false' for an animation that survived the cancellation would return it to the pool while it's still alive
            }
            if (!d.isPaused) {
                if (d.isUpdatedInJob) {
                    d.isUpdatedInJob = false;
                    bool isDone = d.isDone;
                    if (d.isValueChanged) {
                        if (!ReportOnValueChange(ref d)) {
                            return false;
                        }
                    }

                    // a callback can stop the tween emergently, for example, by destroying the target and completing the tween
                    if (isDone && d.isAlive) {
                        // tween
                        if (!d.isPaused) {
                            Kill(ref d);
                        }
                        ReportOnComplete(ref d); // tween
                        return d.isAlive; // a tween paused by its last callback stays alive until it's unpaused
                    }
                    return true;
                }
                bool isTicked = true;
                float timeScale = d.timeScale;
                #if PRIME_TWEEN_EXPERIMENTAL
                if (d.HasClock) {
                    var clock = cold.onUpdateTarget as Tween.Clock;
                    Assert.IsNotNull(clock);
                    if (clock.isManual) {
                        isTicked = clock.TryGetDeltaTime(out dt);
                    }
                    // clamped to keep the max cycles per update within the limit described in PrimeTweenConfig.ManualUpdate()
                    timeScale = Mathf.Clamp(timeScale * clock.timeScale, -Tween.maxTimeScale, Tween.maxTimeScale);
                    // Tween.timeScale setter rejects negative values on wait sequences, but the clock doesn't know its animations, so negative time is clamped here
                    if (d.HasWait && dt * timeScale < 0f) {
                        dt = 0f;
                    }
                }
                #endif
                if (isTicked) {
                    return SetElapsedTimeTotal(d.elapsedTimeTotal + dt * timeScale, true, ref d);
                }
            }
            if (IsUnityTargetDestroyed()) {
                EmergencyStop(true, ref d);
                return false;
            }
            // ReSharper disable once ConditionIsAlwaysTrueOrFalse
            return d.isAlive;
        }

        internal bool SetElapsedTimeTotal(float newElapsedTimeTotal, bool earlyExitSequenceIfPaused, ref UnmanagedTweenData d) {
            Assert.IsFalse(d.isUpdatedInJob);
            if (d.isInSequence) {
                Assert.IsTrue(sequence.data.isAlive, id);
                if (d.IsMainSequenceRoot()) {
                    Assert.IsTrue(sequence == cold, id);
                    Assert.IsFalse(d.isUpdating);
                    if (d.HasWait
                        && earlyExitSequenceIfPaused // ignore HasWait when called from progress and elapsedTime
                       ) {
                        if (cold.waitPredicateShouldWait != null) {
                            float dt = newElapsedTimeTotal - d.elapsedTimeTotal;
                            var sequencePayload = cold.blob.Load<SequencePayload>();
                            sequencePayload.waitTimeout -= dt;
                            cold.blob.Store(sequencePayload);
                            if (!cold.waitPredicateShouldWait(cold) || sequencePayload.waitTimeout <= 0f) {
                                // Reset main sequence wait data
                                cold.waitPredicateTarget = null;
                                cold.waitPredicate = null;
                                cold.waitPredicateShouldWait = null;
                            }
                        } else {
                            // Callbacks of children can't seek the sequence while it iterates them, see Tween.SetElapsedTimeTotal()
                            d.isUpdating = true;
                            UpdateSequenceUpToFirstWait(newElapsedTimeTotal, ref d);
                        }
                    } else {
                        d.isUpdating = true;
                        UpdateSequence(newElapsedTimeTotal, false, earlyExitSequenceIfPaused, true, false, ref d);
                    }
                    d.isUpdating = false;
                }
            } else {
                UpdateAndSetElapsedTimeTotal(newElapsedTimeTotal, out int cyclesDiff, false, ref d);
                if (!d.stoppedEmergently && d.isAlive && d.IsDone(cyclesDiff)) { // tween
                    if (!d.isPaused) {
                        Kill(ref d);
                    }
                    ReportOnComplete(ref d); // tween
                }
            }
            return d.isAlive;
        }

        internal void UpdateSequence(float _elapsedTimeTotal, bool isRestart, bool earlyExitSequenceIfPaused, bool allowSkipChildrenUpdate, bool invertEase, ref UnmanagedTweenData d) {
            Assert.IsTrue(d.IsSequenceRoot());

            bool isRootBackwardCycle = (d.clampCyclesDone(d.cyclesDone) % 2 != 0) ^ d.isSequenceInverted;
            float prevElapsedTime = FloatVal(d.startValue, d.easedInterpolationFactor, endValueOrDiff);
            bool invertRootEase = (d.cyclesTotal == 1 && isRootBackwardCycle && d.cycleMode == CycleMode.Rewind) ^ invertEase;
            if (!UpdateAndSetElapsedTimeTotal(_elapsedTimeTotal, out int cyclesDiff, invertRootEase, ref d) && allowSkipChildrenUpdate) { // update sequence root
                return;
            }

            if (d.cycleMode == (CycleMode)_CycleMode.YoyoChildren && isRootBackwardCycle) {
                invertEase = !invertEase;
            }
            bool isRestartToBeginning = isRestart && cyclesDiff < 0;
            Assert.IsTrue(!isRestartToBeginning || d.cyclesDone == 0 || d.cyclesDone == iniCyclesDone);
            if (cyclesDiff != 0 && !isRestartToBeginning) {
                // print($"           sequence cyclesDiff: {cyclesDiff}");
                if (isRestart) {
                    Assert.IsTrue(cyclesDiff > 0);
                    if (d.cyclesDone == d.cyclesTotal) {
                        cyclesDiff = 1;
                    } else {
                        // a restarting parent moves this sequence to its first cycle, not to the end
                        isRestart = false;
                    }
                }
                int cyclesDiffAbs = Mathf.Abs(cyclesDiff);
                int newCyclesDone = d.cyclesDone;
                if (d.IsMainSequenceRoot() && d.IsDone(cyclesDiff)) {
                    // the callbacks invoked by this update can't prevent the sequence from completing. See CompleteContractSequenceIsDeadIfItsLastCallbackPausesIt
                    d.IsCompleting = true;
                }
                d.cyclesDone -= cyclesDiff;
                int cyclesDelta = cyclesDiff > 0 ? 1 : -1;
                const int maxSequenceCyclesPerUpdate = 1000;
                if (cyclesDiffAbs > maxSequenceCyclesPerUpdate) {
                    // Every crossed cycle moves the children to absolute positions and depends only on 'cyclesDone', so skipping the earlier cycles doesn't change the final state
                    LogErrorWithStackTrace($"Sequence crossed {cyclesDiffAbs} cycles in one update, but max {maxSequenceCyclesPerUpdate} cycles are processed per update. The callbacks of the skipped cycles will not be invoked. Sequence: {GetDescription()}");
                    d.cyclesDone += (cyclesDiffAbs - maxSequenceCyclesPerUpdate) * cyclesDelta;
                    cyclesDiffAbs = maxSequenceCyclesPerUpdate;
                }
                float interpolationFactor = cyclesDelta > 0 ? 1f : 0f;
                for (int i = 0; i < cyclesDiffAbs; i++) {
                    Assert.IsTrue(!isRestart || i == 0);
                    if (d.cyclesDone == d.cyclesTotal || d.cyclesDone == iniCyclesDone) {
                        // do nothing when moving backward from the last cycle or forward from the -1 cycle
                        d.cyclesDone += cyclesDelta;
                        continue;
                    }

                    float easedT = CalcEasedT(interpolationFactor, false, ref d);
                    bool isForwardCycle = (easedT > 0.5f) ^ d.isSequenceInverted;

                    // complete the previous cycles by forcing all children tweens to 0f or 1f
                    // print($" (i:{i}) force child to isForwardCycle: {isForwardCycle}");
                    float forceChildrenToPosElapsedTime = isForwardCycle ? float.MaxValue : negativeElapsedTime;
                    foreach (var tween in GetSequenceSelfChildren(isForwardCycle)) {
                        tween.managedData.UpdateSequenceChild(forceChildrenToPosElapsedTime, isRestart, invertEase, ref tween.data);
                        if (isEarlyExitAfterChildUpdate(ref d)) {
                            return;
                        }
                    }

                    d.cyclesDone += cyclesDelta;
                    if (cyclesDelta > 0 && d.cyclesDone == d.cyclesTotal) {
                        // a callback has shortened the sequence with SetRemainingCycles(), so it completes now without crossing the rest of the cycles
                        break;
                    }
                    var sequenceCycleMode = d.cycleMode;
                    if (sequenceCycleMode == CycleMode.Restart && d.cyclesDone != d.cyclesTotal && d.cyclesDone != iniCyclesDone) { // '&& cyclesDone != 0' check is wrong because we should do the restart when moving from 1 to 0 cyclesDone
                        // print($"restartChildren to pos: {!isForwardCycle}");
                        float restartChildrenElapsedTime = !isForwardCycle ? float.MaxValue : negativeElapsedTime;
                        prevElapsedTime = restartChildrenElapsedTime;
                        foreach (var tween in GetSequenceSelfChildren(!isForwardCycle)) {
                            tween.managedData.UpdateSequenceChild(restartChildrenElapsedTime, true, invertEase, ref tween.data);
                            if (isEarlyExitAfterChildUpdate(ref d)) {
                                return;
                            }
                            Assert.IsTrue(isForwardCycle || tween.data.cyclesDone == tween.data.cyclesTotal, id);
                            Assert.IsTrue(!isForwardCycle || tween.data.cyclesDone <= 0, id);
                            Assert.IsTrue(isForwardCycle || tween.data.GetState() == State.After, id);
                            Assert.IsTrue(!isForwardCycle || tween.data.GetState() == State.Before, id);
                        }
                    }
                }
                Assert.IsTrue(newCyclesDone == d.cyclesDone || d.cyclesDone == d.cyclesTotal, id);
                if (d.IsDone(cyclesDiff)) { // sequence
                    if (d.IsMainSequenceRoot()) {
                        // the sequence is already at its end, so Complete() called from OnUpdate() can't finish the completion
                        d.IsResetting = true;
                        ReportSequenceOnUpdate(ref d);
                        if (d.isAlive && d.resetOnComplete) {
                            ResetSequence(sequence);
                        }
                        d.IsResetting = false;
                        if (!d.isAlive) {
                            return; // OnUpdate() or a reset callback stopped the sequence
                        }
                        if (!d.isPaused) {
                            new Sequence(sequence).ReleaseTweens();
                        } else {
                            // the sequence was paused before it reached the end, so it stays alive until it's unpaused. See UnpauseCompletedSequenceShouldRelease
                            d.IsCompleting = false;
                        }
                        // children are no longer iterated, so the sequence's own OnComplete can seek it
                        d.isUpdating = false;
                    } else {
                        ReportSequenceOnUpdate(ref d);
                        if (!d.isAlive) {
                            return;
                        }
                    }
                    ReportOnComplete(ref d, false); // sequence
                    return;
                }
            }

            float encompassingElapsedTime = Mathf.Clamp(FloatVal(d.startValue, d.easedInterpolationFactor, endValueOrDiff), 0f, d.cycleDuration);
            bool isForward = encompassingElapsedTime > prevElapsedTime;
            foreach (var t in GetSequenceSelfChildren(isForward)) {
                t.managedData.UpdateSequenceChild(encompassingElapsedTime, isRestart, invertEase, ref t.data);
                if (isEarlyExitAfterChildUpdate(ref d)) {
                    return;
                }
            }
            ReportSequenceOnUpdate(ref d);

            bool isEarlyExitAfterChildUpdate(ref UnmanagedTweenData d2) {
                if (!d2.isAlive) {
                    return true;
                }
                return earlyExitSequenceIfPaused && d2.isPaused; // access isPaused via root tween to bypass the cantManipulateNested check
            }
        }

        bool UpdateSequenceUpToFirstWait(float newElapsedTimeTotal, ref UnmanagedTweenData d) {
            Assert.IsTrue(d.IsSequenceRoot());
            Assert.AreEqual(1, d.cyclesTotal);
            Assert.AreEqual(Ease.Linear, d.ease);
            Assert.IsFalse(d.isSequenceInverted);

            float encompassingElapsedTime = newElapsedTimeTotal - d.waitDelay;
            foreach (var child in GetSequenceSelfChildren(true)) {
                ref var childData = ref child.data;
                ref TweenData childManagedData = ref child.managedData;
                if (childData.IsSequenceRoot()) {
                    if (childData.HasWait) {
                        if (childManagedData.UpdateSequenceUpToFirstWait(encompassingElapsedTime, ref childData)) {
                            return true;
                        }
                    } else {
                        // A sibling's wait doesn't restrict this sequence's cycles, easing, or direction.
                        childManagedData.UpdateSequenceChild(encompassingElapsedTime, false, false, ref childData);
                    }
                } else {
                    // update tweens and execute OnComplete up to the first suspending HasWait
                    if (childData.elapsedTimeTotal < encompassingElapsedTime // update tweens only forward
                        && childManagedData.UpdateAndSetElapsedTimeTotal(encompassingElapsedTime, out int cyclesDiff, false, ref childData)
                       ) {
                        if (!d.isAlive || d.isPaused) {
                            return false;
                        }
                        if (!childData.stoppedEmergently && childData.isAlive) {
                            bool shouldWait = childData.HasWait && child.waitPredicateShouldWait(child);
                            if (!d.isAlive) {
                                // The predicate can stop or complete the sequence and unlink all its children.
                                return true;
                            }
                            if (shouldWait) {
                                // Copy wait data to the main sequence
                                var mainSequence = child.FindMainSequence();
                                mainSequence.waitPredicateTarget = child.waitPredicateTarget;
                                mainSequence.waitPredicate = child.waitPredicate;
                                mainSequence.waitPredicateShouldWait = child.waitPredicateShouldWait;
                                var sequencePayload = mainSequence.blob.Load<SequencePayload>();
                                sequencePayload.waitTimeout = child.blob.Load<WaitPayload>().timeout;
                                mainSequence.blob.Store(sequencePayload);
                                return true;
                            } else if (cyclesDiff != 0
                                       && childData.IsDone(cyclesDiff) // sequence child
                                       && childData.GetCallbackDirection() != TweenAnimation.CallbackDirection.BackwardOnly
                                      ) {
                                childManagedData.ReportOnComplete(ref childData); // sequence child
                            }
                        }
                    }
                }
                if (!d.isAlive) {
                    // a callback has stopped or completed the sequence, so its children can't be enumerated anymore
                    return true;
                }
            }

            if (UpdateAndSetElapsedTimeTotal(newElapsedTimeTotal, out int seqCyclesDiff, false, ref d)) { // update sequence root if no children exited early because of ChainWait
                bool isDone = d.IsDone(seqCyclesDiff);
                if (isDone && d.IsMainSequenceRoot()) {
                    d.IsCompleting = true;
                    d.IsResetting = true;
                }
                ReportSequenceOnUpdate(ref d);
                if (isDone) { // sequence
                    if (d.IsMainSequenceRoot()) {
                        if (d.isAlive && d.resetOnComplete) {
                            ResetSequence(sequence);
                        }
                        d.IsResetting = false;
                        if (!d.isAlive) {
                            return false;
                        }
                        if (!d.isPaused) {
                            new Sequence(sequence).ReleaseTweens();
                        } else {
                            d.IsCompleting = false;
                        }
                        d.isUpdating = false;
                    } else if (!d.isAlive) {
                        return false;
                    }
                    ReportOnComplete(ref d, false); // sequence
                }
            }
            return false;
        }

        internal static void ResetSequence(ColdData seq, bool toEnd = false) {
            ref var seqData = ref seq.data;
            Assert.IsTrue(seqData.isAlive);

            bool isResetToEnd = IsResetToEnd(ref seqData, toEnd);
            foreach (var child in new Sequence(seq).GetSelfChildren(isForward: isResetToEnd)) {
                ref var childData = ref child.data;

                int tweenCyclesTotal = childData.cyclesTotal;
                Assert.AreNotEqual(-1, tweenCyclesTotal); // nested animations can't be infinite
                childData.cyclesDone = isResetToEnd ? tweenCyclesTotal : iniCyclesDone; // setting the cyclesDone to tweenCyclesTotal prevents callback from firing because isDone requires 'cyclesDiff > 0'

                // Also update nested sequence root
                childData.SetState(State.None); // guarantees propagation of state change
                float elapsedTimeTotal = isResetToEnd ? float.MaxValue : negativeElapsedTime;
                bool isValueChanged = child.managedData.UpdateAndSetElapsedTimeTotal(elapsedTimeTotal, out _, false, ref childData);
                Assert.IsTrue(isValueChanged);
                if (!seqData.isAlive) {
                    return;
                }
                Assert.AreEqual(isResetToEnd ? State.After : State.Before, childData.GetState());

                if (childData.IsSequenceRoot()) {
                    ResetSequence(child, isResetToEnd);
                    if (!seqData.isAlive) {
                        return; // a nested reset callback can stop the entire sequence
                    }
                }
            }
            seq.managedData.ReportSequenceOnUpdate(ref seqData);
        }

        // 'toEnd' is relative to the playback direction, which is reversed if the sequence is inverted. A sequence with an even number of Yoyo or Rewind cycles ends where it starts
        internal static bool IsResetToEnd(ref UnmanagedTweenData seqData, bool toEnd) => seqData.isSequenceInverted ^ (toEnd && (seqData.cycleMode == CycleMode.Restart || seqData.cyclesTotal % 2 != 0));

        internal static void InvertSequence(Sequence seq) {
            var root = seq.root.tween;
            ref var d = ref root.data;
            (d.startValue, root.managedData.endValueOrDiff) = (root.managedData.endValueOrDiff, d.startValue); // sequence uses startValue and endValue as bounds for time calculation. Swapping them makes the sequence go in the opposite direction.
            d.isSequenceInverted = true;
            CacheDiff(ref d, ref root.managedData);
        }

        Sequence.SequenceDirectEnumerator GetSequenceSelfChildren(bool isForward) {
            Assert.IsTrue(sequence.data.isAlive, id);
            return new Sequence(sequence).GetSelfChildren(isForward);
        }

        void UpdateSequenceChild(float encompassingElapsedTime, bool isRestart, bool invertEase, ref UnmanagedTweenData d) {
            if (d.IsSequenceRoot()) {
                UpdateSequence(encompassingElapsedTime, isRestart, true, true, invertEase, ref d);
            } else {
                UpdateAndSetElapsedTimeTotal(encompassingElapsedTime, out int cyclesDiff, invertEase, ref d);
                if (!d.stoppedEmergently && d.isAlive && cyclesDiff != 0) {
                    var callbackDirection = d.GetCallbackDirection();
                    if (d.tweenType == TweenType.Callback && (int)callbackDirection != 0) {
                        if (!isRestart) {
                            if (callbackDirection != TweenAnimation.CallbackDirection.BackwardOnly && cyclesDiff > 0 && d.cyclesDone == d.cyclesTotal) {
                                cold.onComplete?.Invoke(this);
                            }
                            if (callbackDirection != TweenAnimation.CallbackDirection.ForwardOnly && cyclesDiff < 0 && d.cyclesDone == iniCyclesDone) {
                                cold.onComplete?.Invoke(this);
                            }
                        }
                    } else if (d.IsDone(cyclesDiff)) { // sequence child
                        ReportOnComplete(ref d); // sequence child
                    }
                }
            }
        }

        internal bool UpdateAndSetElapsedTimeTotal(float newElapsedTimeTotal, out int cyclesDiff, bool invertEase, ref UnmanagedTweenData d) {
            int oldCyclesDone = d.cyclesDone;
            float t = d.UpdateData(newElapsedTimeTotal);
            cyclesDiff = d.cyclesDone - oldCyclesDone;
            if (d.isValueChanged) {
                d.easedInterpolationFactor = CalcEasedT(t, invertEase, ref d);

                if (TryCacheDiff(ref d)) {
                    ReportOnValueChange(ref d);
                }
                return true;
            }
            return false;
        }


        [System.Diagnostics.Conditional("PRIME_TWEEN_SAFETY_CHECKS")]
        internal void print(string msg) {
            // Debug.Log($"[{Time.frameCount}] id:{id}  {msg}  tweenType:{cold.data.tweenType} {GetDescription()}", target as UnityEngine.Object);
        }

        internal void Reset(ref UnmanagedTweenData d) {
            Assert.IsFalse(d.isUpdating);
            Assert.IsFalse(d.isAlive);
            Assert.IsNull(cold.sequence);
            Assert.IsNull(cold.prev);
            Assert.IsNull(cold.next);
            Assert.IsNull(cold.prevSibling);
            Assert.IsNull(cold.nextSibling);
            Assert.IsFalse(d.isInSequence);
            // a shake that is still startFromCurrent has never called TryTakeStartValueFromOtherShake(), so it doesn't hold a reference in the 'shakes' dict
            if (Utils.IsShake(d.tweenType) && !d.startFromCurrent) {
                ShakeData.Reset(target, d.tweenType);
            }
            cold.blob = default;
            #if UNITY_EDITOR
            debugDescription = null;
            #endif
            target = null;
            cold.customEase = null;
            cold.customOnValueChange = null;
            cold.onValueChange = null;
            cold.onComplete = null;
            cold.onCompleteCallback = null;
            cold.onCompleteTarget = null;
            cold.waitPredicateTarget = null;
            cold.waitPredicate = null;
            cold.waitPredicateShouldWait = null;
            cold.cancellationToken = CancellationToken.None;
            clearOnUpdate(ref d);

            Assert.IsTrue(cold.hasData);
            Assert.AreEqual(id, d.id);
            d = default; // reset the data before returning tween to pool
            id = -1;
        }

        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        internal void OnComplete([CanBeNull] Action _onComplete, bool? warnIfTargetDestroyed) {
            if (_onComplete == null) {
                return;
            }
            if (!ValidateOnCompleteAssignment()) {
                return;
            }
            cold.data.warnIgnoredOnCompleteIfTargetDestroyed = warnIfTargetDestroyed ?? PrimeTweenManager.Instance.warnIfTargetDestroyed;
            cold.onCompleteCallback = _onComplete;
            cold.onComplete = tween => {
                var callback = tween.cold.onCompleteCallback as Action;
                Assert.IsNotNull(callback);
                try {
                    callback();
                } catch (Exception e) {
                    tween.HandleOnCompleteException(e);
                }
            };
        }

        internal void OnComplete<T>([CanBeNull] T _target, [CanBeNull] Action<T> _onComplete, bool? warnIfTargetDestroyed) where T : class {
            if (_target == null || IsDestroyedUnityObject(_target)) {
                Debug.LogError($"{nameof(_target)} is null or has been destroyed. {Constants.onCompleteCallbackIgnored}");
                return;
            }
            if (_onComplete == null) {
                return;
            }
            if (!ValidateOnCompleteAssignment()) {
                return;
            }
            cold.data.warnIgnoredOnCompleteIfTargetDestroyed = warnIfTargetDestroyed ?? PrimeTweenManager.Instance.warnIfTargetDestroyed;
            cold.onCompleteTarget = _target;
            cold.onCompleteCallback = _onComplete;
            cold.onComplete = tween => {
                var callback = tween.cold.onCompleteCallback as Action<T>;
                Assert.IsNotNull(callback);
                var _onCompleteTarget = tween.cold.onCompleteTarget as T;
                if (IsDestroyedUnityObject(_onCompleteTarget)) {
                    tween.WarnOnCompleteIgnored(true);
                    return;
                }
                try {
                    callback(_onCompleteTarget);
                } catch (Exception e) {
                    tween.HandleOnCompleteException(e);
                }
            };
        }

        internal static bool CheckPayloadSize<TPayload>() where TPayload : unmanaged {
            if (UnsafeUtility.SizeOf<TPayload>() > ColdData.userPayloadSize) {
                Debug.LogError($"Payload '{typeof(TPayload)}' is {UnsafeUtility.SizeOf<TPayload>()} bytes, but the max supported size is {ColdData.userPayloadSize} bytes.");
                return false;
            }
            return true;
        }

        internal void OnComplete<T, TPayload>([CanBeNull] T _target, TPayload payload, [CanBeNull] Action<T, TPayload> _onComplete, bool? warnIfTargetDestroyed) where T : class where TPayload : unmanaged {
            if (_target == null || IsDestroyedUnityObject(_target)) {
                Debug.LogError($"{nameof(_target)} is null or has been destroyed. {Constants.onCompleteCallbackIgnored}");
                return;
            }
            if (_onComplete == null) {
                return;
            }
            if (!ValidateOnCompleteAssignment()) {
                return;
            }
            ref var d = ref cold.data;
            Assert.IsTrue(d.tweenType == TweenType.Delay || d.tweenType == TweenType.Callback);
            d.warnIgnoredOnCompleteIfTargetDestroyed = warnIfTargetDestroyed ?? PrimeTweenManager.Instance.warnIfTargetDestroyed;
            cold.blob.Store(payload);

            cold.onCompleteTarget = _target;
            cold.onCompleteCallback = _onComplete;
            cold.onComplete = tween => {
                var callback = tween.cold.onCompleteCallback as Action<T, TPayload>;
                Assert.IsNotNull(callback);
                var _onCompleteTarget = tween.cold.onCompleteTarget as T;
                if (IsDestroyedUnityObject(_onCompleteTarget)) {
                    tween.WarnOnCompleteIgnored(true);
                    return;
                }
                var _payload = tween.cold.blob.Load<TPayload>();
                try {
                    callback(_onCompleteTarget, _payload);
                } catch (Exception e) {
                    tween.HandleOnCompleteException(e);
                }
            };
        }

        void HandleOnCompleteException(Exception e) {
            // Design decision: if a tween is inside a Sequence and the user's tween.OnComplete() throws an exception, the Sequence should continue
            LogErrorWithStackTrace($"Tween's onComplete callback raised exception, tween: {GetDescription()}");
            Debug.LogException(e, target as UnityEngine.Object);
        }

        internal void LogErrorWithStackTrace(string msg) => Assert.LogErrorWithStackTrace(msg, cold.id, target);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static bool IsDestroyedUnityObject<T>(T obj) where T: class => obj is UnityEngine.Object unityObject && unityObject == null;

        bool ValidateOnCompleteAssignment() {
            if (cold.onCompleteTarget != null || cold.onCompleteCallback != null || cold.onComplete != null) {
                LogErrorWithStackTrace(Constants.onCompleteDuplicateError);
                return false;
            }
            return true;
        }

        internal bool ReportOnValueChange(ref UnmanagedTweenData d) {
            // print($"ReportOnValueChange {d.easedInterpolationFactor}, {Vector4Val(d.startValue, d.easedInterpolationFactor, endValueOrDiff)}, {d.startValue}, {endValueOrDiff}");
            Assert.IsFalse(d.startFromCurrent);
            bool hasOnUpdate = d.hasOnUpdate;
            try {
                // The value setter can fail even if the Unity target is not destroyed. For example, ScrollRect.SetNormalizedPosition can throw null ref if m_Content is not populated: https://github.com/needle-mirror/com.unity.ugui/blob/a601a2bf30161c47959231b627a8c40f64d69a68/Runtime/UI/Core/ScrollRect.cs#L1031.
                // Also, this try-catch catches exceptions in user-provided setter callbacks in Custom tweens.
                if (!Utils.SetAnimatedValue(ref this, ref d, ref cold.blob)) {
                    return false;
                }
                // a sequence root updates before its children, so its OnUpdate() is invoked by UpdateSequence() after the children are updated
                if (hasOnUpdate && !d.stoppedEmergently && d.isAlive && !d.IsSequenceRoot()) {
                    d.isUpdating = true;
                    cold.onUpdate?.Invoke(this);
                    d.isUpdating = false;
                }
            } catch (Exception e) {
                Debug.LogException(e, target as UnityEngine.Object);
                Assert.LogWarningWithStackTrace($"Tween was stopped because of exception in '{nameof(ColdData.onValueChange)}', tween: {GetDescription()}\n", id, target);
                EmergencyStop(false, ref d);
                return false;
            }
            return true;
        }

        // Returns false if Tween.Custom's getter has stopped or completed the tween, so the value shouldn't be reported
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        bool TryCacheDiff(ref UnmanagedTweenData d) {
            if (d.startFromCurrent) {
                if (!ShakeData.TryTakeStartValueFromOtherShake(ref this, ref d)) {
                    if (!IsUnityTargetDestroyed()) {
                        bool wasAlive = d.isAlive;
                        d.isUpdating = true;
                        try {
                            if (cold.customGetterInvoker is OnValueChangeDelegate customGetterInvoker) {
                                customGetterInvoker(ref this, ref d);
                            } else {
                                // can throw even if the Unity target is not destroyed. For example, ScrollRect.SetNormalizedPosition can throw without the content reference
                                d.startValue = Utils.GetAnimatedValue(target, d.tweenType, ref cold.blob);
                            }
                        } catch (Exception e) {
                            Debug.LogException(e, target as UnityEngine.Object);
                            LogErrorWithStackTrace($"Getting the current value raised exception, so the tween starts from the 'startValue' instead of the current value, tween: {GetDescription()}");
                        } finally {
                            d.isUpdating = false;
                        }
                        // customGetterInvoker can call Stop/Complete()
                        if (wasAlive && !d.isAlive) {
                            return false;
                        }
                    }
                }
                d.startFromCurrent = false;
                if (d.warnEndValueEqualsCurrent && !Utils.IsShake(d.tweenType) && EndValueEqualsCurrent(ref d)) {
                    Assert.LogWarningWithStackTrace($"Tween's 'endValue' equals to the current animated value: {d.startValue.vector4}, tween: {GetDescription()}.\n" +
                                      $"{Constants.buildWarningCanBeDisabledMessage(nameof(PrimeTweenConfig.warnEndValueEqualsCurrent))}\n", id, target);
                }
                CacheDiff(ref d, ref this);
            }
            return true;
        }

        bool EndValueEqualsCurrent(ref UnmanagedTweenData d) {
            // For quaternions, q and -q represent the same rotation, so compare by angle instead of by raw components.
            return d.propType == PropType.Quaternion
                ? TweenAnimation.ValueWrapper.QuaternionAngle(d.startValue, endValueOrDiff) == 0f
                : d.startValue.vector4 == endValueOrDiff.vector4;
        }

        void ReportOnComplete(ref UnmanagedTweenData d, bool canResetOnComplete = true) {
            // print($"ReportOnComplete() {d.easedInterpolationFactor}");
            // a startFromCurrent tween can return to its start before its first value change, so it never reads the start value
            Assert.IsTrue(!d.startFromCurrent || d.cyclesDone == iniCyclesDone);
            // An animation completes at its end or at its start. The direction can't be checked with the timeScale: the job computes the completion before the main loop invokes callbacks, and a callback of an earlier animation can change the timeScale
            Assert.IsTrue(d.cyclesDone == d.cyclesTotal || d.cyclesDone == iniCyclesDone);
            if (d.cyclesDone == d.cyclesTotal) {
                if (canResetOnComplete && d.resetOnComplete && !d.isInSequence) {
                    // reset Tween
                    UpdateAndSetElapsedTimeTotal(negativeElapsedTime, out _, false, ref d);
                }
                cold.onComplete?.Invoke(this);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal bool IsUnityTargetDestroyed() {
            // must use target here instead of unityTarget
            // unityTarget has the SerializeField attribute, so if ReferenceEquals(unityTarget, null), then Unity will populate the field with non-null UnityEngine.Object when a new scene is loaded in the Editor
            // https://github.com/KyryloKuzyk/PrimeTween/issues/32
            return IsDestroyedUnityObject(target);
        }

        internal bool HasOnComplete => cold.onComplete != null;

        [NotNull]
        internal string GetDescription() {
            var _sb = PrimeTweenManager.Instance._stringBuilder;
            _sb.Clear();
            var d = cold.data;
            if (!d.isAlive) {
                _sb.Append(" - ");
            }

            // _sb.Append(id).Append(" ");

            if (sequence != null) {
                var currentSequence = sequence;
                while (true) {
                    if (id != currentSequence.id) {
                        _sb.Append(" · "); // p2 todo animations are ordered by creation time, not by sequence nesting depth
                    }
                    var _prev = currentSequence.prev;
                    if (_prev == null) {
                        break;
                    }
                    var parent = _prev.sequence;
                    if (parent == null) {
                        break;
                    }
                    currentSequence = parent;
                }
            }

            switch (d.tweenType) {
                case TweenType.Delay:
                    _sb.Append("Delay");
                    break;
                case TweenType.Callback:
                    _sb.Append("Callback");
                    break;
                case TweenType.MainSequence:
                case TweenType.NestedSequence:
                    _sb.Append("Sequence ");
                    break;
                default:
                    _sb.Append(d.tweenType);
                    break;
            }

            const string separator = "  /  ";
            if (target != PrimeTweenManager.dummyTarget) {
                _sb.Append(separator);
                string targetName =
                    target is UnityEngine.Object unityObject && unityObject != null ? unityObject.name :
                    cold.customOnValueChange is UnityEngine.Object tweenAnimationContext && tweenAnimationContext != null ? tweenAnimationContext.name :
                    target?.GetType().Name;
                _sb.Append(targetName);
            }
            if (d.tweenType != TweenType.Callback) {
                _sb.Append(separator).AppendFormat("{0:0.0#}s", d.animationDuration);
            }
            return _sb.ToString();
        }

        internal static void CalculateCycleDuration(float endDelay, ref UnmanagedTweenData d) {
            Assert.IsTrue(endDelay >= 0f);
            d.cycleDuration = Mathf.Min(d.startDelay + d.animationDuration + endDelay, float.MaxValue); // the sum of finite values can overflow to infinity
        }

        internal static double DoubleVal(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => startValue.DoubleVal + delta.DoubleVal * t;
        internal static float FloatVal(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => startValue.single + delta.single * t;
        internal static Color ColorVal(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => startValue.color + delta.color * t;
        internal static Vector2 Vector2Val(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => startValue.vector2 + delta.vector2 * t;
        internal static Vector3 Vector3Val(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => startValue.vector3 + delta.vector3 * t;
        internal static Vector4 Vector4Val(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => startValue.vector4 + delta.vector4 * t;
        internal static Rect RectVal(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => new Rect(
            startValue.x + delta.x * t,
            startValue.y + delta.y * t,
            startValue.z + delta.z * t,
            startValue.w + delta.w * t);
        internal static Quaternion QuaternionVal(TweenAnimation.ValueWrapper startValue, float t, TweenAnimation.ValueWrapper delta) => Quaternion.SlerpUnclamped(startValue.quaternion, delta.quaternion, t);

        // UnmanagedTweenData.calcEasedT() that also supports Ease.Custom
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal float CalcEasedT(float t, bool invertEase, ref UnmanagedTweenData d) => d.easeOutput(Evaluate(d.easeInput(t, invertEase), ref d), invertEase);

        float Evaluate(float t, ref UnmanagedTweenData d) {
            if (d.ease == Ease.Custom) {
                var curve = cold.customEase;
                if (curve != null) {
                    return curve.Evaluate(t);
                }
                return Easing.EvaluateParametricEase(t, ref this, ref d);
            }
            return StandardEasing.Evaluate(t, d.ease);
        }

        internal static void CacheDiff(ref UnmanagedTweenData d, ref TweenData rt) {
            // print($"CacheDiff, startValue: {d.startValue}, endValue: {endValue}");
            Assert.IsFalse(d.startFromCurrent);
            var propType = d.propType;
            Assert.AreNotEqual(PropType.None, propType);
            if (Utils.IsShake(d.tweenType)) {
                // shakes store the strength in endValueOrDiff
                if (propType == PropType.Quaternion) {
                    d.startValue.QuaternionNormalize();
                }
                return;
            }
            switch (propType) {
                case PropType.Quaternion:
                    d.startValue.QuaternionNormalize();
                    rt.endValueOrDiff.QuaternionNormalize();
                    break;
                case PropType.Double:
                    rt.endValueOrDiff.DoubleVal -= d.startValue.DoubleVal;
                    rt.endValueOrDiff.z = 0f;
                    rt.endValueOrDiff.w = 0f;
                    break;
                default:
                    rt.endValueOrDiff.vector4 -= d.startValue.vector4;
                    break;
            }
            // rt.print($"CacheDiff, diff: {rt.endValueOrDiff}");
        }

        internal void ForceComplete(ref UnmanagedTweenData d) {
            Assert.IsNull(sequence);
            Kill(ref d); // protects from recursive call
            int cyclesTotal_;
            if (d.timeScale > 0f) {
                cyclesTotal_ = d.cyclesTotal;
            if (cyclesTotal_ == -1) {
                // same as SetRemainingCycles(1)
                cyclesTotal_ = d.getCyclesDone() + 1;
                d.cyclesTotal = cyclesTotal_;
            }
            } else {
                cyclesTotal_ = iniCyclesDone;
            }
            d.cyclesDone = cyclesTotal_;
            d.easedInterpolationFactor = CalcEasedT(1f, false, ref d);

            TryCacheDiff(ref d);
            ReportOnValueChange(ref d);

            if (d.stoppedEmergently) {
                return;
            }
            ReportOnComplete(ref d);
            Assert.IsFalse(d.isAlive);
        }

        internal void WarnOnCompleteIgnored(bool isTargetDestroyed) {
            if (HasOnComplete && cold.data.warnIgnoredOnCompleteIfTargetDestroyed) {
                cold.onComplete = null;
                var msg = $"{Constants.onCompleteCallbackIgnored} Tween: {GetDescription()}.\n";
                if (isTargetDestroyed) {
                    msg += "\nIf you use tween.OnComplete(), Tween.Delay(), or sequence.ChainDelay() only for cosmetic purposes, you can turn off this error by passing 'warnIfTargetDestroyed: false' parameter to the method.\n" +
                           "More info: https://github.com/KyryloKuzyk/PrimeTween/discussions/4\n\n" +
                           "Not recommended: it's also possible to disable this setting globally with '" + nameof(PrimeTweenConfig) + "." + nameof(PrimeTweenConfig.warnIfTargetDestroyed) + " = false', but doing so will silent potential logic errors and might introduce subtle hard-to-debug issues to your project.\n";
                }
                Assert.LogErrorWithStackTrace(msg, id, target ?? cold.onCompleteTarget);
            }
        }

        internal void EmergencyStop(bool isTargetDestroyed, ref UnmanagedTweenData d) {
            if (sequence != null) {
                ColdData mainSequence = cold.FindMainSequence();
                Assert.IsTrue(mainSequence.data.isAlive);
                Assert.IsTrue(mainSequence.data.IsMainSequenceRoot());
                new Sequence(mainSequence).EmergencyStop();
            } else if (d.isAlive) {
                // EmergencyStop() can be called after ForceComplete() and a caught exception in Tween.Custom()
                Kill(ref d);
            }
            d.stoppedEmergently = true;
            WarnOnCompleteIgnored(isTargetDestroyed);
            Assert.IsFalse(d.isAlive);
            Assert.IsNull(sequence);
        }

        internal void Kill(ref UnmanagedTweenData d) {
            // print($"kill {GetDescription()}");
            Assert.IsTrue(d.isAlive);
            d.isAlive = false;
            #if UNITY_EDITOR
            debugDescription = null;
            #endif
        }

        internal void SetOnUpdate<T>(T _target, [NotNull] Delegate _onUpdate) where T : class {
            if (cold.onUpdate != null) {
                LogErrorWithStackTrace(cold.data.hasOnUpdate ? Constants.onUpdateDuplicateError : Constants.onFinallyAndOnUpdateError);
                return;
            }
            if (cold.data.HasClock) {
                LogErrorWithStackTrace(Constants.clockAndCallbacksError);
                return;
            }
            if (_onUpdate == null) {
                LogErrorWithStackTrace("'onUpdate' is null.");
                return;
            }
            cold.onUpdateTarget = _target;
            cold.onUpdateCallback = _onUpdate;
            cold.onUpdate = reusableTween => reusableTween.invokeOnUpdate<T>();
            cold.data.hasOnUpdate = true;
        }

        void ReportSequenceOnUpdate(ref UnmanagedTweenData d) {
            Assert.IsTrue(d.IsSequenceRoot());
            if (d.hasOnUpdate && d.isAlive) {
                cold.onUpdate(this);
            }
        }

        void invokeOnUpdate<T>() where T : class {
            var callback = cold.onUpdateCallback;
            Assert.IsNotNull(callback);
            var _onUpdateTarget = cold.onUpdateTarget as T;
            if (IsDestroyedUnityObject(_onUpdateTarget)) {
                LogErrorWithStackTrace($"OnUpdate() will not be called again because OnUpdate()'s target has been destroyed, tween: {GetDescription()}");
                clearOnUpdate(ref cold.data);
                return;
            }
            try {
                if (callback is Action<T, Tween> tweenCallback) {
                    tweenCallback(_onUpdateTarget, new Tween(cold));
                } else {
                    var sequenceCallback = callback as Action<T, Sequence>;
                    Assert.IsNotNull(sequenceCallback);
                    sequenceCallback(_onUpdateTarget, new Sequence(cold));
                }
            } catch (Exception e) {
                LogErrorWithStackTrace($"OnUpdate() will not be called again because it thrown exception, tween: {GetDescription()}");
                Debug.LogException(e, _onUpdateTarget as UnityEngine.Object);
                clearOnUpdate(ref cold.data);
            }
        }

        // OnFinally() reuses the OnUpdate() storage. 'onUpdate != null && !hasOnUpdate' means the animation has OnFinally()

        internal void ReportOnFinally() {
            var onFinally = cold.onUpdate;
            if (onFinally != null && !cold.data.hasOnUpdate) {
                // cleared before the invocation so that a later stop path (for example, triggered by a callback) doesn't invoke it twice. The invoker clears the rest of the fields
                cold.onUpdate = null;
                onFinally(this);
            }
        }

        void clearOnUpdate(ref UnmanagedTweenData d) {
            cold.onUpdateTarget = null;
            cold.onUpdateCallback = null;
            cold.onUpdate = null;
            d.hasOnUpdate = false;
        }

        public override string ToString() {
            return GetDescription();
        }

        public bool Equals(TweenData other) {
            return Equals(cold, other.cold);
        }

        public override bool Equals(object obj) {
            return obj is TweenData other && Equals(other);
        }

        public override int GetHashCode() {
            return (cold != null ? cold.GetHashCode() : 0);
        }
    }

    [Flags]
    internal enum Flags {
        Additive = 1 << 0,
        ShakeSign = 1 << 1,
        ShakePunch = 1 << 2,
        WarnEndValueEqualsCurrent = 1 << 3,
        WarnIgnoredOnCompleteIfTargetDestroyed = 1 << 4,
        ResetOnComplete = 1 << 5,
        IsUpdating = 1 << 6,
        StoppedEmergently = 1 << 7,
        IsAlive = 1 << 8,
        StateLow = 1 << 9,
        StateHigh = 1 << 10,
        IsResetting = 1 << 11, // Complete() called by the sequence's OnUpdate() or a callback of the reset is ignored: the interrupted completion finishes the sequence. See ResetSequence()
        StartFromCurrent = 1 << 12,
        IsDone = 1 << 13,
        IsValueChanged = 1 << 14,
        UseUnscaledTime = 1 << 15,
        IsInSequence = 1 << 16,
        IsPaused = 1 << 17,
        IsUpdatedInJob = 1 << 18,
        HasOnUpdate = 1 << 19,
        HasWait = 1 << 20,
        IsSequenceInverted = 1 << 21,
        IsCustomEaseSameStartEndValues = 1 << 22,
        CallbackDirectionLow = 1 << 23, // TweenAnimation.CallbackDirection packed into two bits, 0 means disabled
        CallbackDirectionHigh = 1 << 24,
        CancellationModeComplete = 1 << 25, // unset means CancellationMode.Stop
        ModificationIsNotAllowed = 1 << 26,
        HasCancellationToken = 1 << 27,
        HasClock = 1 << 28, // ColdData.onUpdateTarget holds the Tween.Clock
        IsCompleting = 1 << 29,
        JobStateLow = 1 << 30,
        JobStateHigh = 1 << 31,
    }

    internal enum State : byte {
        None,
        Before,
        Running,
        After,
    }

    internal enum _CycleMode : byte {
        Restart = 0,
        Yoyo = 1,
        Incremental = 2,
        Rewind = 3,
        YoyoChildren = 4
    }

    internal delegate void OnValueChangeDelegate(ref TweenData rt, ref UnmanagedTweenData d);
}
