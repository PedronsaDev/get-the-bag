/*
// ReSharper disable PossibleNullReferenceException
// ReSharper disable UnusedMember.Global
// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedMember.Local
using System;
using System.ComponentModel;
using JetBrains.Annotations;
using TweenType = PrimeTween.TweenAnimation.TweenType;

namespace PrimeTween {
    internal static class CodeTemplates {
        public static Tween PositionAtSpeed([NotNull] UnityEngine.Transform target,                                 UnityEngine.Vector3 endValue, float averageSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false) => PositionAtSpeed(target, new TweenSettings<UnityEngine.Vector3>(            endValue, new TweenSettings(averageSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween PositionAtSpeed([NotNull] UnityEngine.Transform target, UnityEngine.Vector3 startValue, UnityEngine.Vector3 endValue, float averageSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false) => PositionAtSpeed(target, new TweenSettings<UnityEngine.Vector3>(startValue, endValue, new TweenSettings(averageSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
               static Tween PositionAtSpeed([NotNull] UnityEngine.Transform target, TweenSettings<UnityEngine.Vector3> settings) {
            var speed = settings.settings.duration;
            if (speed <= 0) {
                UnityEngine.Debug.LogError($"Invalid speed provided to the Tween.{nameof(PositionAtSpeed)}() method: {speed}.");
                return default;
            }
            if (settings.startFromCurrent) {
                settings.startFromCurrent = false;
                settings.startValue = target != null ? target.position : default; // creating the tween reports the destroyed target
            }
            settings.settings.duration = Extensions.CalcDistance(settings.startValue, settings.endValue) / speed;
            return Tween.Position(target, settings);
        }


        [EditorBrowsable(EditorBrowsableState.Never), Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]      public static Tween METHOD_NAME([NotNull] UnityEngine.Camera target,                    Single endValue, TweenSettings settings) => METHOD_NAME(target, new TweenSettings<float>(            endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never), Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)] public static Tween METHOD_NAME([NotNull] UnityEngine.Camera target, Single startValue, Single endValue, TweenSettings settings) => METHOD_NAME(target, new TweenSettings<float>(startValue, endValue, settings));
        public static Tween METHOD_NAME([NotNull] UnityEngine.Camera target,                    Single endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)    => METHOD_NAME(target, new TweenSettings<float>(            endValue, duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime));
        public static Tween METHOD_NAME([NotNull] UnityEngine.Camera target, Single startValue, Single endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)    => METHOD_NAME(target, new TweenSettings<float>(startValue, endValue, duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime));
        public static Tween METHOD_NAME([NotNull] UnityEngine.Camera target, TweenSettings<float> settings) => animate(target, ref settings, TweenType.CameraOrthographicSize);


        [EditorBrowsable(EditorBrowsableState.Never), Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween Custom_TEMPLATE(                       Single startValue, Single endValue, TweenSettings settings, [NotNull] Action<   Single> onValueChange)                 => Custom_TEMPLATE(        new TweenSettings<float>(startValue, endValue,   settings), onValueChange);
        [EditorBrowsable(EditorBrowsableState.Never), Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween Custom_TEMPLATE<T>([NotNull] T target, Single startValue, Single endValue, TweenSettings settings, [NotNull] Action<T, Single> onValueChange) where T : class => Custom_TEMPLATE(target, new TweenSettings<float>(startValue, endValue,   settings), onValueChange);
        /// <inheritdoc cref="AdditiveTweensDoc"/>
        public static Tween CustomAdditive<T> ([NotNull] T target, Single deltaValue,                  TweenSettings settings, [NotNull] Action<T, Single> onDeltaChange, [CanBeNull] Func<T, Single> getCurrentValue = null, bool useDurationAsSpeed = false) where T : class => CustomGeneric(target, new AdditivePayload(), new TweenSettings<float>(default,    deltaValue, settings).ToContainer(), onDeltaChange, getCurrentValue, TweenType.CustomFloat, useDurationAsSpeed);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom_TEMPLATE                       (Single startValue, Single endValue, float duration,         [NotNull] Action<   Single> onValueChange, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)                 => Custom_TEMPLATE(        new TweenSettings<float>(startValue, endValue, duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime), onValueChange);
        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom_TEMPLATE<T>([NotNull] T target, Single startValue, Single endValue, float duration,         [NotNull] Action<T, Single> onValueChange, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false) where T : class => Custom_TEMPLATE(target, new TweenSettings<float>(startValue, endValue, duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime), onValueChange);
        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom_TEMPLATE<T>([NotNull] T target, TweenSettings<float> settings,                              [NotNull] Action<T, Single> onValueChange, [CanBeNull] Func<T, Single> getCurrentValue = null, bool useDurationAsSpeed = false)                                                                                                     where T : class => CustomGeneric(target, new NoPayload(), settings.ToContainer(), onValueChange, getCurrentValue, TweenType.CustomFloat, useDurationAsSpeed);
        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom_TEMPLATE<T, TPayload>([NotNull] T target, TPayload payload, TweenSettings<float> settings, [NotNull] Action<T, TPayload, Single> onValueChange, [CanBeNull] Func<T, TPayload, Single> getCurrentValue = null, bool useDurationAsSpeed = false) where T : class where TPayload : unmanaged
            => CustomGeneric(target, payload, settings.ToContainer(), onValueChange, getCurrentValue, TweenType.CustomFloat, useDurationAsSpeed);
        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom_TEMPLATE(                       TweenSettings<float> settings,                              [NotNull] Action<   Single> onValueChange, [CanBeNull] Func<Single> getCurrentValue = null, bool useDurationAsSpeed = false) => CustomGeneric(PrimeTweenManager.dummyTarget, new NoTargetNoPayload(), settings.ToContainer(), onValueChange, getCurrentValue, TweenType.CustomFloat, useDurationAsSpeed);
        static Tween animate(object target, ref TweenSettings<float> settings, TweenType _tweenType) {
            if (PrimeTweenManager.Instance.isDestroyed) {
                return default;
            }
            var tween = PrimeTweenManager.FetchTween(settings.settings._updateType);
            ref var d = ref tween.data;
            ref var rt = ref tween.managedData;

            d.startValue.CopyFrom(ref settings.startValue);
            rt.endValueOrDiff.CopyFrom(ref settings.endValue);

            tween.Setup(target, ref settings.settings, settings.startFromCurrent, _tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }


        /// <inheritdoc cref="AdditiveTweensDoc"/>
        public static Tween PositionAdditive([NotNull] UnityEngine.Transform target, Single deltaValue, float duration, Easing ease = default,    int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false) => PositionAdditive(target, deltaValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime));
        /// <inheritdoc cref="AdditiveTweensDoc"/>
        public static Tween PositionAdditive([NotNull] UnityEngine.Transform target, Single deltaValue, TweenSettings settings)                                                                                                                                                    => CustomAdditive  (target, deltaValue, settings, (_target, delta) => additiveTweenSetter(), _target => additiveTweenGetter());

        static void additiveTweenSetter() {}
        static float additiveTweenGetter() => 0f;
    }
}
*/
